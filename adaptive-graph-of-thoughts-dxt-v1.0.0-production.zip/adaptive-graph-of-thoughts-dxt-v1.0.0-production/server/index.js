#!/usr/bin/env node

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ListPromptsRequestSchema,
  GetPromptRequestSchema,
  ErrorCode,
  McpError,
} from '@modelcontextprotocol/sdk/types.js';
import { z } from 'zod';
import axios from 'axios';
import { logger } from './logger.js';
import { ErrorHandler, safeStringify } from './error-handler.js';

// Configuration schema
const ConfigSchema = z.object({
  neo4j_uri: z.string().default('bolt://localhost:7687'),
  neo4j_username: z.string().default('neo4j'),
  neo4j_password: z.string(),
  openai_api_key: z.string().optional(),
  anthropic_api_key: z.string().optional(),
  pubmed_api_key: z.string().optional(),
  enable_external_search: z.boolean().default(true),
  max_reasoning_depth: z.number().min(1).max(10).default(5),
  confidence_threshold: z.number().min(0).max(1).default(0.7),
});

// Tool input schemas
const ScientificReasoningQuerySchema = z.object({
  query: z.string().describe('The scientific question or research query to analyze'),
  parameters: z.object({
    include_reasoning_trace: z.boolean().default(true).describe('Include detailed reasoning steps'),
    include_graph_state: z.boolean().default(false).describe('Include graph state information'),
    max_depth: z.number().min(1).max(10).optional().describe('Override maximum reasoning depth'),
    confidence_threshold: z.number().min(0).max(1).optional().describe('Override confidence threshold'),
  }).optional(),
});

const AnalyzeResearchHypothesisSchema = z.object({
  hypothesis: z.string().describe('The research hypothesis to analyze'),
  context: z.string().optional().describe('Additional context or background information'),
  evidence_sources: z.array(z.string()).optional().describe('Specific evidence sources to consider'),
});

const ExploreScientificRelationshipsSchema = z.object({
  concepts: z.array(z.string()).describe('Scientific concepts to explore relationships between'),
  relationship_types: z.array(z.string()).optional().describe('Specific types of relationships to focus on'),
  depth: z.number().min(1).max(5).default(3).describe('Depth of relationship exploration'),
});

const ValidateScientificClaimsSchema = z.object({
  claims: z.array(z.string()).describe('Scientific claims to validate'),
  evidence_requirement: z.enum(['low', 'medium', 'high']).default('medium').describe('Level of evidence required'),
  sources: z.array(z.string()).optional().describe('Preferred evidence sources'),
});

class AdaptiveGraphOfThoughtsServer {
  constructor() {
    this.server = new Server(
      {
        name: 'adaptive-graph-of-thoughts',
        version: '1.0.0',
      },
      {
        capabilities: {
          tools: {},
          prompts: {},
        },
      }
    );

    logger.info('Initializing Adaptive Graph of Thoughts DXT Server');
    this.config = this.loadConfig();
    this.baseUrl = 'http://localhost:8000'; // Default Python server URL
    this.setupToolHandlers();
    this.setupPromptHandlers();
    this.setupErrorHandling();
    logger.info('Server initialization complete');
  }

  loadConfig() {
    try {
      logger.debug('Loading configuration from environment variables');
      
      // Load configuration from environment variables or defaults
      const config = {
        neo4j_uri: process.env.NEO4J_URI || 'bolt://localhost:7687',
        neo4j_username: process.env.NEO4J_USERNAME || 'neo4j', 
        neo4j_password: process.env.NEO4J_PASSWORD || '',
        openai_api_key: process.env.OPENAI_API_KEY,
        anthropic_api_key: process.env.ANTHROPIC_API_KEY,
        pubmed_api_key: process.env.PUBMED_API_KEY,
        enable_external_search: process.env.ENABLE_EXTERNAL_SEARCH !== 'false',
        max_reasoning_depth: parseInt(process.env.MAX_REASONING_DEPTH) || 5,
        confidence_threshold: parseFloat(process.env.CONFIDENCE_THRESHOLD) || 0.7,
      };

      const validatedConfig = ConfigSchema.parse(config);
      
      logger.info('Configuration loaded successfully', {
        neo4j_uri: validatedConfig.neo4j_uri.replace(/\/\/.*@/, '//*****@'), // Mask credentials in URI
        neo4j_username: validatedConfig.neo4j_username,
        enable_external_search: validatedConfig.enable_external_search,
        max_reasoning_depth: validatedConfig.max_reasoning_depth,
        confidence_threshold: validatedConfig.confidence_threshold,
        has_openai_key: !!validatedConfig.openai_api_key,
        has_anthropic_key: !!validatedConfig.anthropic_api_key,
        has_pubmed_key: !!validatedConfig.pubmed_api_key,
      });
      
      return validatedConfig;
    } catch (error) {
      logger.error('Configuration validation failed', { error: error.message });
      throw ErrorHandler.handleConfigurationError(error);
    }
  }

  setupErrorHandling() {
    ErrorHandler.setupGlobalErrorHandlers(this.server);
  }

  setupToolHandlers() {
    this.server.setRequestHandler(ListToolsRequestSchema, async () => {
      return {
        tools: [
          {
            name: 'scientific_reasoning_query',
            description: 'Advanced scientific reasoning with graph analysis using the ASR-GoT framework',
            inputSchema: {
              type: 'object',
              properties: {
                query: {
                  type: 'string',
                  description: 'The scientific question or research query to analyze'
                },
                parameters: {
                  type: 'object',
                  description: 'Optional parameters',
                  properties: {
                    include_reasoning_trace: {
                      type: 'boolean',
                      description: 'Include detailed reasoning steps',
                      default: true
                    },
                    include_graph_state: {
                      type: 'boolean', 
                      description: 'Include graph state information',
                      default: false
                    },
                    max_depth: {
                      type: 'number',
                      description: 'Override maximum reasoning depth',
                      minimum: 1,
                      maximum: 10
                    },
                    confidence_threshold: {
                      type: 'number',
                      description: 'Override confidence threshold',
                      minimum: 0,
                      maximum: 1
                    }
                  }
                }
              },
              required: ['query']
            },
          },
          {
            name: 'analyze_research_hypothesis',
            description: 'Hypothesis evaluation with confidence scoring and evidence integration',
            inputSchema: {
              type: 'object',
              properties: {
                hypothesis: {
                  type: 'string',
                  description: 'The research hypothesis to analyze'
                },
                context: {
                  type: 'string',
                  description: 'Additional context or background information'
                },
                evidence_sources: {
                  type: 'array',
                  items: { type: 'string' },
                  description: 'Specific evidence sources to consider'
                }
              },
              required: ['hypothesis']
            },
          },
          {
            name: 'explore_scientific_relationships',
            description: 'Concept relationship mapping through graph-based analysis',
            inputSchema: {
              type: 'object',
              properties: {
                concepts: {
                  type: 'array',
                  items: { type: 'string' },
                  description: 'Scientific concepts to explore relationships between'
                },
                relationship_types: {
                  type: 'array',
                  items: { type: 'string' },
                  description: 'Specific types of relationships to focus on'
                },
                depth: {
                  type: 'number',
                  description: 'Depth of relationship exploration',
                  minimum: 1,
                  maximum: 5,
                  default: 3
                }
              },
              required: ['concepts']
            },
          },
          {
            name: 'validate_scientific_claims',
            description: 'Evidence-based claim validation with external database integration',
            inputSchema: {
              type: 'object',
              properties: {
                claims: {
                  type: 'array',
                  items: { type: 'string' },
                  description: 'Scientific claims to validate'
                },
                evidence_requirement: {
                  type: 'string',
                  enum: ['low', 'medium', 'high'],
                  description: 'Level of evidence required',
                  default: 'medium'
                },
                sources: {
                  type: 'array',
                  items: { type: 'string' },
                  description: 'Preferred evidence sources'
                }
              },
              required: ['claims']
            },
          },
        ],
      };
    });

    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;

      logger.info('Tool call received', { toolName: name, args: safeStringify(args) });

      try {
        let result;
        switch (name) {
          case 'scientific_reasoning_query':
            result = await this.handleScientificReasoningQuery(args);
            break;
          case 'analyze_research_hypothesis':
            result = await this.handleAnalyzeResearchHypothesis(args);
            break;
          case 'explore_scientific_relationships':
            result = await this.handleExploreScientificRelationships(args);
            break;
          case 'validate_scientific_claims':
            result = await this.handleValidateScientificClaims(args);
            break;
          default:
            throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${name}`);
        }
        
        logger.info('Tool call completed successfully', { toolName: name });
        return result;
      } catch (error) {
        throw ErrorHandler.handleToolError(error, name, args);
      }
    });
  }

  setupPromptHandlers() {
    this.server.setRequestHandler(ListPromptsRequestSchema, async () => {
      return {
        prompts: [
          {
            name: 'analyze_research_question',
            description: 'Generate comprehensive analysis of a scientific research question',
            arguments: [
              {
                name: 'research_question',
                description: 'The research question to analyze',
                required: true,
              },
              {
                name: 'domain',
                description: 'Scientific domain or field',
                required: false,
              },
            ],
          },
          {
            name: 'hypothesis_generator',
            description: 'Generate and evaluate multiple hypotheses for a given scientific problem',
            arguments: [
              {
                name: 'problem_statement',
                description: 'The scientific problem to generate hypotheses for',
                required: true,
              },
              {
                name: 'constraints',
                description: 'Any constraints or limitations to consider',
                required: false,
              },
            ],
          },
          {
            name: 'literature_synthesis',
            description: 'Synthesize findings from multiple research papers into coherent insights',
            arguments: [
              {
                name: 'research_papers',
                description: 'List of research papers or citations to synthesize',
                required: true,
              },
              {
                name: 'synthesis_focus',
                description: 'Specific aspect or theme to focus the synthesis on',
                required: false,
              },
            ],
          },
        ],
      };
    });

    this.server.setRequestHandler(GetPromptRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;

      switch (name) {
        case 'analyze_research_question':
          return {
            description: 'Comprehensive research question analysis',
            messages: [
              {
                role: 'user',
                content: {
                  type: 'text',
                  text: `Please analyze the following research question using the Adaptive Graph of Thoughts framework:

Research Question: ${args?.research_question}
${args?.domain ? `Domain: ${args.domain}` : ''}

Provide a comprehensive analysis including:
1. Problem decomposition and key dimensions
2. Hypothesis generation and evaluation
3. Evidence requirements and sources
4. Potential relationships and dependencies
5. Confidence assessment and reasoning trace`,
                },
              },
            ],
          };

        case 'hypothesis_generator':
          return {
            description: 'Multi-hypothesis generation and evaluation',
            messages: [
              {
                role: 'user',
                content: {
                  type: 'text',
                  text: `Generate and evaluate multiple hypotheses for the following scientific problem:

Problem: ${args?.problem_statement}
${args?.constraints ? `Constraints: ${args.constraints}` : ''}

For each hypothesis, provide:
1. Clear hypothesis statement
2. Testability assessment
3. Evidence requirements
4. Confidence scoring
5. Potential alternative explanations`,
                },
              },
            ],
          };

        case 'literature_synthesis':
          return {
            description: 'Research literature synthesis and analysis',
            messages: [
              {
                role: 'user',
                content: {
                  type: 'text',
                  text: `Synthesize the following research papers into coherent insights:

Research Papers: ${args?.research_papers}
${args?.synthesis_focus ? `Focus Area: ${args.synthesis_focus}` : ''}

Provide a comprehensive synthesis including:
1. Common themes and patterns across papers
2. Contradictory findings and potential explanations
3. Knowledge gaps and future research directions
4. Methodological considerations and limitations
5. Practical implications and applications
6. Confidence assessment of synthesized conclusions`,
                },
              },
            ],
          };

        default:
          throw new McpError(ErrorCode.InvalidRequest, `Unknown prompt: ${name}`);
      }
    });
  }

  async makeBackendRequest(endpoint, data, timeout = 30000) {
    const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    logger.debug('Making backend request', {
      requestId,
      endpoint,
      timeout,
      dataSize: JSON.stringify(data).length,
    });

    try {
      const startTime = Date.now();
      const response = await axios.post(`${this.baseUrl}${endpoint}`, data, {
        timeout,
        headers: {
          'Content-Type': 'application/json',
          'X-Request-ID': requestId,
        },
      });
      
      const duration = Date.now() - startTime;
      logger.debug('Backend request completed', {
        requestId,
        status: response.status,
        duration,
        responseSize: JSON.stringify(response.data).length,
      });
      
      return response.data;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error('Backend request failed', {
        requestId,
        endpoint,
        error: error.message,
        code: error.code,
        status: error.response?.status,
        duration,
      });
      
      throw error; // Let ErrorHandler.handleToolError handle the specific error types
    }
  }

  async handleScientificReasoningQuery(args) {
    try {
      const input = ScientificReasoningQuerySchema.parse(args);
      
      logger.info('Processing scientific reasoning query', {
        queryLength: input.query.length,
        hasParameters: !!input.parameters,
      });
    
      const requestData = {
        jsonrpc: '2.0',
        method: 'asr_got.query',
        params: {
          query: input.query,
          parameters: {
            ...input.parameters,
            max_depth: input.parameters?.max_depth || this.config.max_reasoning_depth,
            confidence_threshold: input.parameters?.confidence_threshold || this.config.confidence_threshold,
          },
        },
        id: `query_${Date.now()}`,
      };

      const result = await this.makeBackendRequest('/mcp', requestData);

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(result, null, 2),
          },
        ],
      };
    } catch (error) {
      if (error instanceof z.ZodError) {
        throw ErrorHandler.handleValidationError(error, args);
      }
      throw error;
    }
  }

  async handleAnalyzeResearchHypothesis(args) {
    try {
      const input = AnalyzeResearchHypothesisSchema.parse(args);
    
      const requestData = {
        jsonrpc: '2.0',
        method: 'analyze_research_hypothesis',
        params: {
          hypothesis: input.hypothesis,
          context: input.context,
          evidence_sources: input.evidence_sources,
          config: {
            confidence_threshold: this.config.confidence_threshold,
            enable_external_search: this.config.enable_external_search,
          },
        },
        id: `hypothesis_${Date.now()}`,
      };

      const result = await this.makeBackendRequest('/mcp', requestData);

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(result, null, 2),
          },
        ],
      };
    } catch (error) {
      if (error instanceof z.ZodError) {
        throw ErrorHandler.handleValidationError(error, args);
      }
      throw error;
    }
  }

  async handleExploreScientificRelationships(args) {
    try {
      const input = ExploreScientificRelationshipsSchema.parse(args);
      
      const requestData = {
        jsonrpc: '2.0',
        method: 'explore_scientific_relationships',
        params: {
          concepts: input.concepts,
          relationship_types: input.relationship_types,
          depth: input.depth,
          config: {
            max_reasoning_depth: this.config.max_reasoning_depth,
          },
        },
        id: `relationships_${Date.now()}`,
      };

      const result = await this.makeBackendRequest('/mcp', requestData);

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(result, null, 2),
          },
        ],
      };
    } catch (error) {
      if (error instanceof z.ZodError) {
        throw ErrorHandler.handleValidationError(error, args);
      }
      throw error;
    }
  }

  async handleValidateScientificClaims(args) {
    try {
      const input = ValidateScientificClaimsSchema.parse(args);
      
      const requestData = {
        jsonrpc: '2.0',
        method: 'validate_scientific_claims',
        params: {
          claims: input.claims,
          evidence_requirement: input.evidence_requirement,
          sources: input.sources,
          config: {
            enable_external_search: this.config.enable_external_search,
            confidence_threshold: this.config.confidence_threshold,
          },
        },
        id: `validation_${Date.now()}`,
      };

      const result = await this.makeBackendRequest('/mcp', requestData);

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(result, null, 2),
          },
        ],
      };
    } catch (error) {
      if (error instanceof z.ZodError) {
        throw ErrorHandler.handleValidationError(error, args);
      }
      throw error;
    }
  }

  async run() {
    try {
      logger.info('Starting Adaptive Graph of Thoughts MCP server');
      const transport = new StdioServerTransport();
      await this.server.connect(transport);
      logger.info('Adaptive Graph of Thoughts MCP server running on stdio');
    } catch (error) {
      logger.error('Failed to start server', { error: error.message, stack: error.stack });
      throw error;
    }
  }
}

// Start the server
const server = new AdaptiveGraphOfThoughtsServer();
server.run().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});